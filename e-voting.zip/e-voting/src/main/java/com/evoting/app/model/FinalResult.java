package com.evoting.app.model;

import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Date;

@Entity
public class FinalResult {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @NotNull
    private States states;

    @ManyToOne(fetch = FetchType.LAZY)
    @NotNull
    private Candidate candidate;

    @UpdateTimestamp
    @NotNull
    private Date timestamp;

    private boolean isVictory = false;

    public FinalResult(){

    }

    public FinalResult(States states, Candidate candidate, Date timestamp, boolean isVictory) {
        this.states = states;
        this.candidate = candidate;
        this.timestamp = timestamp;
        this.isVictory = isVictory;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public States getStates() {
        return states;
    }

    public void setStates(States states) {
        this.states = states;
    }

    public Candidate getCandidate() {
        return candidate;
    }

    public void setCandidate(Candidate candidate) {
        this.candidate = candidate;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public boolean isVictory() {
        return isVictory;
    }

    public void setVictory(boolean victory) {
        isVictory = victory;
    }
}
