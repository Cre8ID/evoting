package com.evoting.app.model;

public enum Role {
    Admin, Election_Commission, Polling_Staff, Voter
}
