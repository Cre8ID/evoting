package com.evoting.app.model;

import javax.persistence.*;
import javax.servlet.http.Part;
import javax.validation.constraints.NotNull;

@Entity
public class Party {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @NotNull
    private byte[] logo;

    @NotNull
    private String name;

    @NotNull
    private String slogan;

    public Party(){

    }

    public Party(byte[] logo, String name, String slogan) {
        this.logo = logo;
        this.name = name;
        this.slogan = slogan;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlogan() {
        return slogan;
    }

    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }
}
