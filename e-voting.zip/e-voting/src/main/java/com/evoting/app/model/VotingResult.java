package com.evoting.app.model;

import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Date;

@Entity
public class VotingResult {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private int voteCount;

    @ManyToOne(fetch = FetchType.LAZY)
    @NotNull
    private Candidate candidate;

    @ManyToOne(fetch = FetchType.LAZY)
    @NotNull
    private States states;

    @UpdateTimestamp
    @NotNull
    private Date timestamp;

    public VotingResult(){

    }

    public VotingResult(int voteCount, Candidate candidate, States states, Date timestamp) {
        this.voteCount = voteCount;
        this.candidate = candidate;
        this.states = states;
        this.timestamp = timestamp;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getVoteCount() {
        return voteCount;
    }

    public void setVoteCount(int voteCount) {
        this.voteCount = voteCount;
    }

    public Candidate getCandidate() {
        return candidate;
    }

    public void setCandidate(Candidate candidate) {
        this.candidate = candidate;
    }

    public States getStates() {
        return states;
    }

    public void setStates(States states) {
        this.states = states;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

}
