package com.evoting.app.web;

public class FlashMessage {
}
